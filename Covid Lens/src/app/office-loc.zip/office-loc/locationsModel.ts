export class LocationsModel {
    location!: Array<String>;
}
