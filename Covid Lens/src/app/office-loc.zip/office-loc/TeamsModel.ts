export class TeamsModel {
   teamName!: Array<String>;
}
