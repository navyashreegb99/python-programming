export class TeamLocationModel {
   teamName!: string;
   location!: string;
 }
 